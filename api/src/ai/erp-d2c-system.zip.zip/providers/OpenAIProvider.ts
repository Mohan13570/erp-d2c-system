import { IAIProvider } from '../interfaces/IAIProvider';
import { AI_CONFIG } from '../config';

export class OpenAIProvider implements IAIProvider {
  private apiKey: string;
  private model: string;

  constructor() {
    this.apiKey = AI_CONFIG.OPENAI_API_KEY;
    this.model = AI_CONFIG.OPENAI_MODEL;
  }

  getName(): string {
    return AI_CONFIG.AI_PROVIDER;
  }

  /**
   * Placeholder generate method – in real code this would call the OpenAI API.
   */
  async generate(prompt: string): Promise<string> {
    // For now just echo back the prompt with a note.
    return `Generated response for prompt: "${prompt}" using model ${this.model}`;
  }
}
