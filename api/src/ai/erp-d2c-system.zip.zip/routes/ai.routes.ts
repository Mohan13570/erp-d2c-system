import { Router, Request, Response, NextFunction } from 'express';
import { AIService } from '../services/AIService';
import logger from '../middleware/logger';

const router = Router();
const aiService = new AIService();

// Apply simple request logger for all AI routes
router.use(logger);

// Health check endpoint
router.get('/health', (req: Request, res: Response) => {
  res.json({ status: 'OK', version: '1.0.0' });
});

// Status endpoint – placeholder
router.get('/status', (req: Request, res: Response) => {
  res.json({ status: 'running', uptime: process.uptime() });
});

// Version endpoint – placeholder
router.get('/version', (req: Request, res: Response) => {
  res.json({ version: '1.0.0', provider: aiService.getProviderName() });
});

// Example AI query endpoint (future implementation)
router.post('/query', async (req: Request, res: Response, next: NextFunction) => {
  try {
    const { prompt } = req.body;
    const result = await aiService.processPrompt(prompt);
    res.json(result);
  } catch (err) {
    next(err);
  }
});

export default router;
