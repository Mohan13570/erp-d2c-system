import { AIService } from '../services/AIService';
import { OpenAIProvider } from '../providers/OpenAIProvider';
import { PromptService } from '../services/PromptService';
import { ConversationService } from '../services/ConversationService';

export class AIService {
  private provider: OpenAIProvider;
  private promptService: PromptService;
  private conversationService: ConversationService;

  constructor() {
    this.provider = new OpenAIProvider();
    this.promptService = new PromptService();
    this.conversationService = new ConversationService();
  }

  /**
   * Returns the name of the AI provider (e.g., "openai").
   */
  getProviderName(): string {
    return this.provider.getName();
  }

  /**
   * Placeholder – processes a prompt using the provider.
   * Future implementation will delegate to provider and handle conversation state.
   */
  async processPrompt(prompt: string): Promise<any> {
    // Simple echo placeholder – real logic will be added later.
    const formatted = this.promptService.formatPrompt(prompt);
    const response = await this.provider.generate(formatted);
    // Store conversation metadata (future).
    await this.conversationService.record(prompt, response);
    return { prompt, response };
  }
}
